
<?php
phpinfo();

?>