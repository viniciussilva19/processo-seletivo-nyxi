<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$mensagem = ''; // Variável para armazenar a mensagem de erro ou sucesso

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nome = isset($_POST['nome']) ? $_POST['nome'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';   
    $message = isset($_POST['message']) ? $_POST['message'] : '';

    // Cria conteúdo para ser salvo
    $conteudo = "Nome: " . htmlspecialchars($nome) . "\n";
    $conteudo .= "E-mail: " . htmlspecialchars($email) . "\n";
    $conteudo .= "Mensagem: \n" . nl2br(htmlspecialchars($message)) . "\n";
    $conteudo .= "-----------------------------\n";

    // Caminho para o arquivo
    $arquivo = 'dados.txt';

    // Tenta abrir o arquivo e adicionar o conteúdo
    if (file_put_contents($arquivo, $conteudo, FILE_APPEND)) {
        // Se o arquivo foi salvo com sucesso
        $mensagem = "<h2>Obrigado pelo seu contato, " . htmlspecialchars($nome) . "!</h2><p>Sua mensagem foi recebida e salva com sucesso.</p>";
    } else { 
        // Se ocorreu um erro ao salvar
        $mensagem = "<h2>Ocorreu um erro ao salvar sua mensagem.</h2><p>Por favor, tente novamente mais tarde.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="forms.ico">
    <title>Formulário de Contato</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background-color: #172d6d;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px #0000001a;
            width: 100%;
            max-width: 400px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #172d6d;
            color: white; 
            border: none;
            border-radius: 4px; 
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #020d2d;
        }

        small {
            color: red;
            font-size: 12px;
        }

        small:empty {
            display: none;
        }

        .message-container {
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Formulário de Contato</h2>
       <form  id="contactForm" action="DadosdoFormulario.php"  method="POST">
            <label for="name">Nome:</label>
            <input type="text" id="name" name="nome" required>
            <small id="nameError"></small>

            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" required>
            <small id="emailError"></small>

            <label for="message">Mensagem:</label>
            <textarea id="message" name="message" required></textarea>
            <small id="messageError"></small>

            <button type="submit">Enviar</button>
        </form>

        <!-- Exibindo a mensagem PHP aqui -->
        <?php if ($mensagem): ?>
            <div class="message-container">
                <?php echo $mensagem; ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
        document.getElementById('contactForm').addEventListener('submit', function(event) {
            event.preventDefault();
            //relatar mensagem de erro
            document.getElementById('nameError').textContent = '';
            document.getElementById('emailError').textContent = '';
            document.getElementById('messageError').textContent = '';

            let valid = true;

            //nome
            const name = document.getElementById('name').value;

            if (name.length < 3) {
                document.getElementById('nameError').textContent = "O nome deve ter pelo menos 3 caracteres"
                valid = false;
            }

            //e-mail

            const email = document.getElementById('email').value;
            const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,6}$/;

            if (!emailPattern.test(email)) {
                document.getElementById('emailError').textContent = "Insira um e-mail válido"
                valid = false;
            }

            //mensagem

            const message = document.getElementById('message').value;

            if (message.length < 10) {
                document.getElementById('messageError').textContent = "A mensagem deve ter pelo menos 10 caracteres"
                valid = false;
            }

            //enviar formulário no caso de informações corretas

            if (valid) {
                alert('Formulário enviado com sucesso!');
                document.getElementById('contactForm').submit()
                document.getElementById('contactForm').reset();
            }
        });
    </script>
</body>
</html>
